const canvas = document.getElementById('stars');
const ctx = canvas.getContext('2d');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let stars = [];

function createStars() {
  for (let i = 0; i < 150; i++) {
    let star = {
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      radius: Math.random() * 2 + 0.5,
      speedX: Math.random() * 0.2 - 0.1,
      speedY: Math.random() * 0.2 - 0.1,
      color: Math.random() < 0.5 ? '#fff' : '#ff6600',
    };
    stars.push(star);
  }
}

function animateStars() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  stars.forEach(star => {
    star.x += star.speedX;
    star.y += star.speedY;

    if (star.x > canvas.width) star.x = 0;
    if (star.x < 0) star.x = canvas.width;
    if (star.y > canvas.height) star.y = 0;
    if (star.y < 0) star.y = canvas.height;

    ctx.beginPath();
    ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
    ctx.fillStyle = star.color;
    ctx.fill();
  });

  requestAnimationFrame(animateStars);
}

createStars();
animateStars();

// Add functionality to video cards
document.querySelectorAll('.video-card').forEach(card => {
  card.addEventListener('click', () => {
    const videoId = card.getAttribute('data-video-id');
    window.open(`https://youtu.be/${videoId}`, '_blank');
  });
});

// Sort video cards based on date
const videoCards = document.querySelectorAll('.video-card');
const videoArray = Array.from(videoCards);

videoArray.sort((a, b) => {
  const dateA = new Date(a.querySelector('.video-date').textContent.replace('🕑 ', ''));
  const dateB = new Date(b.querySelector('.video-date').textContent.replace('🕑 ', ''));
  return dateB - dateA;
});

const videoGrid = document.querySelector('.videos-grid');
videoArray.forEach(card => videoGrid.appendChild(card));

// Giveaways button functionality
const giveawaysButton = document.querySelector('#giveaways-button');
giveawaysButton.addEventListener('click', () => {
  window.open('https://x.com/VideoPower_cs/status/1907819488436797673', '_blank');
});

// Loader functionality
window.onload = function () {
  const loader = document.getElementById('loader');
  loader.style.opacity = 0;
  setTimeout(() => {
    loader.style.display = 'none';
  }, 500);
};
const adBanner = document.querySelector('.ad-banner');

adBanner.addEventListener('mouseover', () => {
  adBanner.style.opacity = '0.8';
});

adBanner.addEventListener('mouseout', () => {
  adBanner.style.opacity = '1';
});
